using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AcademicApp
{
    public interface IGrades
    {
        public abstract void setGrades(int quiz, int midTerm, int Final);
        public abstract double calculateAverage();
        public abstract void getGrades();
    }
}
