using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AcademicApp
{
    public class Student : RegisterSTU, IAcademicID, IGrades
    {
        public int stuNumber { get; set; }

        public Student(int stuNumber, string name, string surname, int age)
            :base(name, surname, age)
        {
            this.stuNumber = stuNumber;
        }

        public double calculateAverage()
        {
            return (quiz * 0.1) + (midTerm * 0.3) + (Final * 0.6);
        }

        public override void display()
        {
            Console.WriteLine("Name: " + name);
            Console.WriteLine("Surname: " + surname);
            Console.WriteLine("Age: " + age);
            this.getAcademicID();
            this.getGrades();
        }

        public void getAcademicID()
        {
            Console.WriteLine("Department: " + department);
            Console.WriteLine("Section: " + section);
            Console.WriteLine("Student ID: " + stuNumber);
        }

        public void getGrades()
        {
            Console.WriteLine("Quiz: " + quiz);
            Console.WriteLine("Midterm: " + midTerm);
            Console.WriteLine("Final: " + Final);
            Console.WriteLine("Average: " + calculateAverage());
        }
        public void setDepartment(string department)
        {
            this.department = department;
        }

        public void setGrades(int quiz, int midTerm, int Final)
        {
            this.quiz = quiz;
            this.midTerm = midTerm;
            this.Final = Final;
        }
        public void setSection(int section)
        {
            this.section = section;
        }

    }
}
