using System;

namespace AcademicApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Student stu = new Student(111, "Mark", "Hall", 21);
            stu.setDepartment("Computing");
            stu.setSection(1);
            stu.setGrades(80, 60, 75);

            stu.display();
        }
    }
}