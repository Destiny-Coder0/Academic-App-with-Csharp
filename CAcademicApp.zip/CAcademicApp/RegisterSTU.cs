using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AcademicApp
{
    public abstract class RegisterSTU
    {
        public string name { get; set; }
        public string surname { get; set; }
        public string department { get; set; }
        public int age { get; set; }
        public int quiz { get; set; }
        public int midTerm { get; set; }
        public int Final { get; set; }
        public int section { get; set; }

        protected RegisterSTU(string name, string surname, int age)
        {
            this.name = name;
            this.surname = surname;
            this.age = age;
        }

        public abstract void display();
    }
}
