using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AcademicApp
{
    public interface IAcademicID
    {
        public abstract void setDepartment(string department);
        public abstract void setSection(int section);
        public abstract void getAcademicID();
    }
}
